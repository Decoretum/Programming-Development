from django.apps import AppConfig


class Halalan2022Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Halalan2022'
