from django.contrib import admin
from .models import Supplier,WaterBottle

admin.site.register(Supplier)
admin.site.register(WaterBottle)
# Register your models here.
